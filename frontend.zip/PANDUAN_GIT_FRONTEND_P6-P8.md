# Panduan Eksekusi Frontend (Mhs 1) - Sprint 1, Pertemuan 6-8

## 0. Menaruh file ke repositori
Salin isi zip ke root repo: folder `client/` dan `docs/`.

```bash
git checkout main && git pull origin main
git checkout -b feat/client-auth-pages
```

## Pertemuan 6 - Feature branch, UI Login/Register
Berkas: `src/components/*`, `src/pages/*`, `src/utils/validation.js`, `src/services/api.js`, `src/App.jsx`, `src/main.jsx`, `src/index.css`, `index.html`, `vite.config.js`, `package.json`.

```bash
cd client && npm install && cp .env.example .env && npm run dev
```
Commit bertahap (jangan satu commit raksasa):
```bash
git add client/package.json client/vite.config.js client/index.html client/src/main.jsx client/src/App.jsx client/src/index.css client/.gitignore client/.env.example
git commit -m "chore(client): scaffold Vite React app with routing"
git add client/src/components
git commit -m "feat(client): add modular InputText, PrimaryButton, AlertToast, AuthCard"
git add client/src/utils/validation.js docs/client_form_validation_rules.md
git commit -m "feat(client): add Zod validation schemas for login and register"
git add client/src/services/api.js
git commit -m "feat(client): add Axios service with JWT interceptor and token storage"
git add client/src/pages
git commit -m "feat(client): implement login and register pages"
git add docs/ui_component_catalog.md
git commit -m "docs(client): add UI component catalog"
git push origin feat/client-auth-pages
```
PR: lampirkan screenshot/GIF form Login & Register (state default, error, loading). Tetapkan reviewer (Backend).

## Pertemuan 7 - ESLint & Prettier
Berkas: `eslint.config.js`, `.prettierrc`.
```bash
cd client && npm run lint && npm run format:check   # keduanya harus bersih
git add client/eslint.config.js client/.prettierrc
git commit -m "chore(client): configure ESLint and Prettier"
git push
```
Beri tahu Mhs 3 perintah untuk CI frontend (jalankan di dalam `client/`): `npm ci`, `npm run lint`, `npm run format:check`, `npm test`, `npm run build`.

## Pertemuan 8 - Unit test client-side
Berkas: `src/**/*.test.js(x)`, `src/test/setup.js`.
```bash
cd client && npm test   # 20 tes lolos
git add client/src/test client/src/utils/validation.test.js client/src/components/InputText.test.jsx client/src/services/api.test.js client/src/pages/Login.test.jsx
git commit -m "test(client): add unit tests for form validation, InputText, and token storage"
git push
```
Catatan: runner yang dipakai Vitest (sintaks `describe/it/expect` sama dengan Jest). Jika dosen mewajibkan Jest, bilang ke Mhs 3 dan saya bisa ubah.

## Template laporan WA (isi data diri sendiri)
```
[PRESENSI SOFTDEV TIF2001]
Pertemuan ke : 6
Nama Mahasiswa : [Nama]
NIM : [NIM]
Kelompok / App : [Kelompok X / ExpiredStock]
Peran Tim : Mhs 1 (Frontend & UI/UX Specialist)

1. Task GitHub Projects : [Issue #... - Slicing UI Form Login & Register]
2. Branch / PR : [URL PR feat/client-auth-pages]
3. Deliverables Hari Ini :
 - Membuat komponen modular InputText, PrimaryButton, AlertToast, AuthCard di client/src/components/
 - Menyelesaikan halaman Login & Register dengan validasi Zod + React Hook Form
4. Status CI / Review : Waiting review dari @[username]
5. Kendala Teknis : [isi kendala nyata / Tidak ada kendala]
```
Pertemuan 7 deliverables: konfigurasi ESLint + Prettier, 0 error `npm run lint`. Status: Passing.
Pertemuan 8 deliverables: 20 skenario unit test (validasi login/register, InputText, tokenStorage) lolos. Status: Passing / Waiting review.
