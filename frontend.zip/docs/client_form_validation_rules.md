# Client Form Validation Rules (Modul Autentikasi)

Sumber kebenaran: `client/src/utils/validation.js` (Zod).

| Form | Field | Aturan | Pesan galat |
|---|---|---|---|
| Login | email | wajib, format email, maks 150 | Email wajib diisi / Format email tidak valid, contoh: nama@perusahaan.com |
| Login | password | wajib, min 8 | Kata sandi wajib diisi / Kata sandi minimal 8 karakter |
| Register | name | 2-100 karakter | Nama minimal 2 karakter / Nama maksimal 100 karakter |
| Register | email | sama dengan login | sama dengan login |
| Register | password | min 8, mengandung huruf dan angka | Kata sandi harus mengandung huruf / angka |
| Register | confirmPassword | wajib, sama dengan password | Konfirmasi kata sandi tidak sama |

Batas `name` (100) dan `email` (150) mengikuti DDL tabel `users` milik Backend. Jika Backend
mengubah aturan password, ubah `validation.js` agar tetap selaras.
