# Katalog Komponen UI Autentikasi

Palet: navy `#1e2d45`, hijau `#047857` (aksi utama), merah `#b91c1c` (galat), latar `#f4f7fc`.
Font: Plus Jakarta Sans.

| Komponen | Props | Variasi status |
|---|---|---|
| `InputText` | `label`, `error`, `hint`, `...input props` | default, focus, error, disabled |
| `PrimaryButton` | `loading`, `disabled`, `type`, `children` | default, hover, loading, disabled |
| `AlertToast` | `type` (`error` / `success`), `message`, `onClose` | error, success |
| `AuthCard` | `title`, `subtitle`, `footer`, `children` | layout dua kolom, satu kolom di mobile (<860px) |
| `ProtectedRoute` | `children` | redirect ke `/login` bila token tidak ada |
