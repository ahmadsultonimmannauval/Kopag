import { beforeEach, describe, expect, it } from 'vitest';
import { getErrorMessage, tokenStorage } from './api.js';

describe('tokenStorage', () => {
  beforeEach(() => localStorage.clear());

  it('menyimpan dan membaca token', () => {
    tokenStorage.set('abc.def.ghi');
    expect(tokenStorage.get()).toBe('abc.def.ghi');
  });

  it('menghapus token', () => {
    tokenStorage.set('abc');
    tokenStorage.clear();
    expect(tokenStorage.get()).toBeNull();
  });
});

describe('getErrorMessage', () => {
  it('401 -> pesan kredensial salah', () => {
    expect(getErrorMessage({ response: { status: 401, data: {} } })).toBe(
      'Email atau kata sandi salah',
    );
  });

  it('409 -> email sudah terdaftar', () => {
    expect(getErrorMessage({ response: { status: 409, data: {} } })).toMatch(
      /sudah terdaftar/,
    );
  });

  it('tanpa response -> server tidak dapat dihubungi', () => {
    expect(getErrorMessage({})).toMatch(/tidak dapat dihubungi/);
  });
});
