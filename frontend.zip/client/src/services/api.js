import axios from 'axios';

const TOKEN_KEY = 'token';

// Penyimpanan token sesi JWT (Local Storage). Dibungkus try/catch agar aman.
export const tokenStorage = {
  get() {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  },
  set(token) {
    try {
      localStorage.setItem(TOKEN_KEY, token);
    } catch {
      /* penyimpanan tidak tersedia */
    }
  },
  clear() {
    try {
      localStorage.removeItem(TOKEN_KEY);
    } catch {
      /* penyimpanan tidak tersedia */
    }
  },
};

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

// Sematkan header Authorization: Bearer <token> otomatis
api.interceptors.request.use((config) => {
  const token = tokenStorage.get();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Token kedaluwarsa (401) saat sesi aktif -> hapus sesi & kembali ke login
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && tokenStorage.get()) {
      tokenStorage.clear();
      window.location.assign('/login');
    }
    return Promise.reject(error);
  },
);

// Kontrak API: POST /api/v1/auth/login & /api/v1/auth/register (sesuaikan dengan docs/api_specifications.md Mhs 2)
export async function loginUser({ email, password }) {
  const { data } = await api.post('/api/v1/auth/login', { email, password });
  return data; // diharapkan: { token, user }
}

export async function registerUser({ name, email, password }) {
  const { data } = await api.post('/api/v1/auth/register', { name, email, password });
  return data;
}

// Ubah error axios menjadi pesan yang jelas untuk pengguna
export function getErrorMessage(error, fallback = 'Terjadi kesalahan. Coba lagi.') {
  if (!error.response) return 'Server tidak dapat dihubungi. Periksa koneksi Anda.';
  const { status, data } = error.response;
  if (status === 401) return 'Email atau kata sandi salah';
  if (status === 409) return 'Email sudah terdaftar. Gunakan email lain atau masuk.';
  return data?.message || fallback;
}

export default api;
