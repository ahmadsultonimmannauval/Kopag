import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import Login from './Login.jsx';

const setup = () =>
  render(
    <MemoryRouter>
      <Login />
    </MemoryRouter>,
  );

describe('Halaman Login', () => {
  it('menampilkan galat validasi saat form kosong dikirim', async () => {
    setup();
    await userEvent.click(screen.getByRole('button', { name: 'Masuk' }));
    expect(await screen.findByText('Email wajib diisi')).toBeInTheDocument();
    expect(await screen.findByText('Kata sandi wajib diisi')).toBeInTheDocument();
  });

  it('menampilkan galat saat kata sandi terlalu pendek', async () => {
    setup();
    await userEvent.type(screen.getByLabelText('Email'), 'sarah@toko.id');
    await userEvent.type(screen.getByLabelText('Kata sandi'), 'abc');
    await userEvent.click(screen.getByRole('button', { name: 'Masuk' }));
    expect(await screen.findByText('Kata sandi minimal 8 karakter')).toBeInTheDocument();
  });
});
