import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import AuthCard from '../components/AuthCard.jsx';
import InputText from '../components/InputText.jsx';
import PrimaryButton from '../components/PrimaryButton.jsx';
import AlertToast from '../components/AlertToast.jsx';
import { loginSchema } from '../utils/validation.js';
import { getErrorMessage, loginUser, tokenStorage } from '../services/api.js';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const [toast, setToast] = useState(
    location.state?.registered
      ? { type: 'success', message: 'Akun berhasil dibuat. Silakan masuk.' }
      : null,
  );

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(loginSchema), mode: 'onBlur' });

  const onSubmit = async (values) => {
    setToast(null);
    try {
      const data = await loginUser(values);
      tokenStorage.set(data.token);
      navigate('/dashboard', { replace: true });
    } catch (err) {
      setToast({ type: 'error', message: getErrorMessage(err) });
    }
  };

  return (
    <AuthCard
      title="Masuk ke ExpiredStock"
      subtitle="Gunakan akun inventory manager Anda."
      footer={
        <>
          Belum punya akun? <Link to="/register">Daftar sekarang</Link>
        </>
      }
    >
      <AlertToast {...(toast || {})} onClose={() => setToast(null)} />
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <InputText
          label="Email"
          type="email"
          autoComplete="email"
          placeholder="nama@perusahaan.com"
          error={errors.email?.message}
          {...register('email')}
        />
        <InputText
          label="Kata sandi"
          type="password"
          autoComplete="current-password"
          placeholder="Minimal 8 karakter"
          error={errors.password?.message}
          {...register('password')}
        />
        <PrimaryButton type="submit" loading={isSubmitting}>
          {isSubmitting ? 'Memproses...' : 'Masuk'}
        </PrimaryButton>
      </form>
    </AuthCard>
  );
}
