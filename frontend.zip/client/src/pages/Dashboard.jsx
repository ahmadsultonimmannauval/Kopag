import { useNavigate } from 'react-router-dom';
import PrimaryButton from '../components/PrimaryButton.jsx';
import { tokenStorage } from '../services/api.js';

// Placeholder: tujuan navigasi setelah login berhasil. Diganti di Sprint 2.
export default function Dashboard() {
  const navigate = useNavigate();
  const logout = () => {
    tokenStorage.clear();
    navigate('/login', { replace: true });
  };

  return (
    <main className="placeholder">
      <h1>Dashboard Inventori &amp; Kedaluwarsa</h1>
      <p>Anda berhasil masuk. Modul dashboard lengkap dikerjakan pada Sprint 2.</p>
      <PrimaryButton onClick={logout}>Keluar</PrimaryButton>
    </main>
  );
}
