import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import AuthCard from '../components/AuthCard.jsx';
import InputText from '../components/InputText.jsx';
import PrimaryButton from '../components/PrimaryButton.jsx';
import AlertToast from '../components/AlertToast.jsx';
import { registerSchema } from '../utils/validation.js';
import { getErrorMessage, registerUser } from '../services/api.js';

export default function Register() {
  const navigate = useNavigate();
  const [toast, setToast] = useState(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(registerSchema), mode: 'onBlur' });

  const onSubmit = async ({ name, email, password }) => {
    setToast(null);
    try {
      await registerUser({ name, email, password });
      navigate('/login', { replace: true, state: { registered: true } });
    } catch (err) {
      setToast({ type: 'error', message: getErrorMessage(err) });
    }
  };

  return (
    <AuthCard
      title="Buat akun baru"
      subtitle="Daftarkan diri untuk mengelola stok dan kedaluwarsa."
      footer={
        <>
          Sudah punya akun? <Link to="/login">Masuk</Link>
        </>
      }
    >
      <AlertToast {...(toast || {})} onClose={() => setToast(null)} />
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <InputText
          label="Nama lengkap"
          autoComplete="name"
          placeholder="Sarah Danastri"
          error={errors.name?.message}
          {...register('name')}
        />
        <InputText
          label="Email"
          type="email"
          autoComplete="email"
          placeholder="nama@perusahaan.com"
          error={errors.email?.message}
          {...register('email')}
        />
        <InputText
          label="Kata sandi"
          type="password"
          autoComplete="new-password"
          hint="Minimal 8 karakter, kombinasi huruf dan angka."
          error={errors.password?.message}
          {...register('password')}
        />
        <InputText
          label="Konfirmasi kata sandi"
          type="password"
          autoComplete="new-password"
          error={errors.confirmPassword?.message}
          {...register('confirmPassword')}
        />
        <PrimaryButton type="submit" loading={isSubmitting}>
          {isSubmitting ? 'Memproses...' : 'Buat akun'}
        </PrimaryButton>
      </form>
    </AuthCard>
  );
}
