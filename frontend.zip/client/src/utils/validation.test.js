import { describe, expect, it } from 'vitest';
import { loginSchema, registerSchema } from './validation.js';

const msg = (result) => result.error.issues.map((i) => i.message);

describe('loginSchema', () => {
  it('menerima email dan kata sandi valid', () => {
    const r = loginSchema.safeParse({ email: 'sarah@toko.id', password: 'rahasia123' });
    expect(r.success).toBe(true);
  });

  it('menolak email salah format', () => {
    const r = loginSchema.safeParse({ email: 'sarah@', password: 'rahasia123' });
    expect(r.success).toBe(false);
    expect(msg(r)[0]).toMatch(/Format email tidak valid/);
  });

  it('menolak email kosong', () => {
    const r = loginSchema.safeParse({ email: '', password: 'rahasia123' });
    expect(msg(r)).toContain('Email wajib diisi');
  });

  it('menolak kata sandi kurang dari 8 karakter', () => {
    const r = loginSchema.safeParse({ email: 'a@b.id', password: 'abc123' });
    expect(msg(r)).toContain('Kata sandi minimal 8 karakter');
  });

  it('boundary: kata sandi tepat 8 karakter diterima', () => {
    expect(loginSchema.safeParse({ email: 'a@b.id', password: '12345678' }).success).toBe(
      true,
    );
  });
});

describe('registerSchema', () => {
  const valid = {
    name: 'Sarah Danastri',
    email: 'sarah@toko.id',
    password: 'rahasia123',
    confirmPassword: 'rahasia123',
  };

  it('menerima data registrasi valid', () => {
    expect(registerSchema.safeParse(valid).success).toBe(true);
  });

  it('menolak nama lebih dari 100 karakter', () => {
    const r = registerSchema.safeParse({ ...valid, name: 'a'.repeat(101) });
    expect(msg(r)).toContain('Nama maksimal 100 karakter');
  });

  it('menolak kata sandi tanpa angka', () => {
    const r = registerSchema.safeParse({
      ...valid,
      password: 'hurufsaja',
      confirmPassword: 'hurufsaja',
    });
    expect(msg(r)).toContain('Kata sandi harus mengandung angka');
  });

  it('menolak kata sandi tanpa huruf', () => {
    const r = registerSchema.safeParse({
      ...valid,
      password: '12345678',
      confirmPassword: '12345678',
    });
    expect(msg(r)).toContain('Kata sandi harus mengandung huruf');
  });

  it('menolak konfirmasi kata sandi yang tidak sama', () => {
    const r = registerSchema.safeParse({ ...valid, confirmPassword: 'beda12345' });
    expect(msg(r)).toContain('Konfirmasi kata sandi tidak sama');
  });
});
