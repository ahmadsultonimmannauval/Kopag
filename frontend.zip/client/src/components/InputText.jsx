import { forwardRef, useId } from 'react';

const InputText = forwardRef(function InputText(
  { label, error, hint, id, className = '', ...rest },
  ref,
) {
  const autoId = useId();
  const inputId = id || autoId;
  const messageId = `${inputId}-msg`;

  return (
    <div className={`field ${error ? 'field--error' : ''} ${className}`}>
      <label htmlFor={inputId} className="field__label">
        {label}
      </label>
      <input
        ref={ref}
        id={inputId}
        className="field__input"
        aria-invalid={error ? 'true' : 'false'}
        aria-describedby={error || hint ? messageId : undefined}
        {...rest}
      />
      {(error || hint) && (
        <p id={messageId} className={error ? 'field__error' : 'field__hint'}>
          {error || hint}
        </p>
      )}
    </div>
  );
});

export default InputText;
