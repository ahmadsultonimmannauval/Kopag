import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import InputText from './InputText.jsx';

describe('InputText', () => {
  it('menampilkan label dan terhubung ke input', () => {
    render(<InputText label="Email" />);
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
  });

  it('menampilkan pesan galat dan menandai aria-invalid', () => {
    render(<InputText label="Email" error="Email wajib diisi" />);
    expect(screen.getByText('Email wajib diisi')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toHaveAttribute('aria-invalid', 'true');
  });

  it('tidak menandai galat saat valid', () => {
    render(<InputText label="Email" />);
    expect(screen.getByLabelText('Email')).toHaveAttribute('aria-invalid', 'false');
  });
});
