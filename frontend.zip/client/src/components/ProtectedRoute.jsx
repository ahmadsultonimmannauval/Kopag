import { Navigate } from 'react-router-dom';
import { tokenStorage } from '../services/api.js';

export default function ProtectedRoute({ children }) {
  return tokenStorage.get() ? children : <Navigate to="/login" replace />;
}
