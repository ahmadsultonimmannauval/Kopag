export default function AuthCard({ title, subtitle, children, footer }) {
  return (
    <main className="auth">
      <aside className="auth__brand">
        <div className="brand">
          <span className="brand__mark" aria-hidden="true">
            ES
          </span>
          <div>
            <strong>ExpiredStock</strong>
            <small>ERP Enterprise</small>
          </div>
        </div>
        <div className="auth__pitch">
          <h2>Setiap batch punya batas waktu. Pantau sebelum terlambat.</h2>
          <ul>
            <li>Peringatan FEFO otomatis per batch</li>
            <li>Mutasi stok tercatat real-time</li>
            <li>Laporan kerugian kedaluwarsa bulanan</li>
          </ul>
        </div>
      </aside>
      <section className="auth__panel">
        <div className="auth__card">
          <h1>{title}</h1>
          <p className="auth__subtitle">{subtitle}</p>
          {children}
          {footer && <p className="auth__footer">{footer}</p>}
        </div>
      </section>
    </main>
  );
}
