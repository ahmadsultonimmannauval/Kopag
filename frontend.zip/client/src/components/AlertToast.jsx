export default function AlertToast({ type = 'error', message, onClose }) {
  if (!message) return null;
  return (
    <div className={`toast toast--${type}`} role={type === 'error' ? 'alert' : 'status'}>
      <span>{message}</span>
      {onClose && (
        <button
          type="button"
          className="toast__close"
          onClick={onClose}
          aria-label="Tutup"
        >
          ×
        </button>
      )}
    </div>
  );
}
